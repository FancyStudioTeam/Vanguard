# ✨ DDenoX

A framework for building Discord applications using Discordeno.

## 📄 License

**[DDenoX][DDenoXRepositoryUrl]** © 2026 by **[FancyStudio][FancyStudioProfileUrl]** is licensed under the **[MIT License][MitLicenseUrl]**.

> **⚠️ This project is not affiliated with Discordeno.**

[DDenoXRepositoryUrl]: https://github.com/FancyStudioTeam/DDenoX
[FancyStudioProfileUrl]: https://github.com/FancyStudioTeam
[MitLicenseUrl]: https://opensource.org/license/mit
